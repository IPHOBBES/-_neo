# RAG Electron App for Technicians

This application allows technicians to upload PDF documents and ask questions about their content. It uses a Retrieval-Augmented Generation (RAG) approach to provide relevant answers from the document.

## Features

- PDF document selection and parsing
- Text extraction and preprocessing
- Text chunking for better retrieval
- Vector-based retrieval system
- Chat interface for querying document content

## Installation

1. Ensure you have Node.js installed (version 14 or higher)
2. Clone or download this repository
3. Navigate to the project directory
4. Install dependencies:
   ```
   npm install
   ```

## Running the Application

You can run the application using one of the following methods:

### Method 1: Using npm

```
npm start
```

### Method 2: Using the run script

```
./run.sh
```

## How to Use

1. Click "Select PDF" to choose a PDF document
2. Once loaded, the PDF content will display on the left panel
3. Type questions about the document in the chat interface on the right
4. The application will retrieve relevant information from the document and display it in the chat

## Technical Details

This application is built using:
- Electron for the desktop application framework
- LangChain for the RAG implementation
- PDF-parse for extracting text from PDFs

The RAG implementation uses a simplified approach with in-memory vector storage to avoid complex native dependencies.

## Troubleshooting

If you encounter any issues:
1. Make sure all dependencies are installed correctly
2. Check that the PDF is not password-protected
3. Ensure the PDF contains extractable text (not just scanned images)

## License

ISC
