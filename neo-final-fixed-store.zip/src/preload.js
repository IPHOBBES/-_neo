const { contextBridge, ipcRenderer } = require('electron');

// Expose protected methods that allow the renderer process to use
// the ipcRenderer without exposing the entire object
contextBridge.exposeInMainWorld(
  'api', {
    selectPdf: () => ipcRenderer.invoke('select-pdf'),
    parsePdf: (filePath) => ipcRenderer.invoke('parse-pdf', filePath),
    queryDocument: (query, documentContent) => ipcRenderer.invoke('query-document', query, documentContent),
    saveRecentFiles: (files) => ipcRenderer.invoke('save-recent-files', files),
    getRecentFiles: () => ipcRenderer.invoke('get-recent-files')
  }
);
