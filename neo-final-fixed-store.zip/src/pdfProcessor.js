// Enhanced PDF processing module with debugging and fallbacks
const fs = require('fs');
const path = require('path');
const pdfParse = require('pdf-parse');
const { RecursiveCharacterTextSplitter } = require('langchain/text_splitter');

// Function to extract text from PDF
async function extractTextFromPdf(filePath) {
  try {
    console.log(`Attempting to extract text from: ${filePath}`);
    const dataBuffer = fs.readFileSync(filePath);
    const data = await pdfParse(dataBuffer);
    
    console.log(`Successfully extracted text. Length: ${data.text.length} characters`);
    console.log(`Page count: ${data.numpages}`);
    
    return {
      text: data.text,
      info: {
        pageCount: data.numpages,
        author: data.info?.Author || 'Unknown',
        title: data.info?.Title || path.basename(filePath)
      }
    };
  } catch (error) {
    console.error('Error extracting text from PDF:', error);
    // Provide a fallback with error information
    return {
      text: `Error extracting text: ${error.message}. This might be due to a corrupted PDF or one without extractable text.`,
      info: {
        pageCount: 0,
        author: 'Unknown',
        title: path.basename(filePath) + ' (Error)'
      }
    };
  }
}

// Function to split text into chunks for better processing
async function splitTextIntoChunks(text, chunkSize = 1000, chunkOverlap = 200) {
  try {
    console.log("Original text length:", text ? text.length : 0);
    
    // If text is empty or too short, return it as a single chunk
    if (!text || text.length < 100) {
      console.log("Text too short, using as single chunk");
      return text && text.trim() ? [text.trim()] : [];
    }
    
    const splitter = new RecursiveCharacterTextSplitter({
      chunkSize,
      chunkOverlap,
    });
    
    const chunks = await splitter.splitText(text);
    console.log(`Split text into ${chunks.length} chunks`);
    
    // Fallback to ensure we always have at least one chunk if text isn't empty
    if (chunks.length === 0 && text.trim().length > 0) {
      chunks.push(text.trim());
      console.log("Using fallback single chunk");
    }
    
    return chunks;
  } catch (error) {
    console.error('Error splitting text into chunks:', error);
    // Return the original text as a single chunk if there's an error
    return text && text.trim() ? [text.trim()] : [];
  }
}

// Function to clean and preprocess text
function preprocessText(text) {
  if (!text) {
    console.log("Warning: Empty text provided to preprocessText");
    return "";
  }
  
  console.log(`Preprocessing text of length: ${text.length}`);
  
  // FIXED: The previous implementation was removing all text
  // Only perform minimal cleaning to preserve content
  
  // Remove excessive whitespace (but keep line breaks)
  let cleaned = text.replace(/[ \t]+/g, ' ');
  
  // Normalize line breaks
  cleaned = cleaned.replace(/\r\n/g, '\n');
  
  // Trim leading/trailing whitespace
  cleaned = cleaned.trim();
  
  console.log(`Preprocessed text length: ${cleaned.length}`);
  
  // IMPORTANT: Return the cleaned text, not an empty string
  return cleaned;
}

module.exports = {
  extractTextFromPdf,
  splitTextIntoChunks,
  preprocessText
};
