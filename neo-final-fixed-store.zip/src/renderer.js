// Renderer process script for the Electron application
// This script runs in the renderer process and handles UI interactions

// DOM Elements
const selectPdfBtn = document.getElementById('select-pdf-btn');
const pdfContent = document.getElementById('pdf-content');
const chatMessages = document.getElementById('chat-messages');
const queryInput = document.getElementById('query-input');
const sendQueryBtn = document.getElementById('send-query-btn');
const loadingIndicator = document.getElementById('loading');
const splashScreen = document.getElementById('splash-screen');
const uploadProgressContainer = document.getElementById('upload-progress-container');
const uploadProgressBar = document.getElementById('upload-progress-bar');
const recentFilesContainer = document.getElementById('recent-files');
const recentFilesList = document.getElementById('recent-files-list');

// Global variables
let currentPdfPath = null;
let documentContent = null;
let recentFiles = [];

// Load recent files from localStorage on startup
window.addEventListener('DOMContentLoaded', () => {
    // Hide splash screen after a delay
    setTimeout(() => {
        splashScreen.style.opacity = '0';
        setTimeout(() => {
            splashScreen.style.display = 'none';
        }, 500);
    }, 2000); // Show splash screen for 2 seconds
    
    // Load recent files
    loadRecentFiles();
});

// Event listeners
selectPdfBtn.addEventListener('click', selectPdf);
sendQueryBtn.addEventListener('click', sendQuery);
queryInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        sendQuery();
    }
});

// Function to load recent files from localStorage
async function loadRecentFiles() {
    try {
        const savedFiles = await window.api.getRecentFiles();
        if (savedFiles && savedFiles.length > 0) {
            recentFiles = savedFiles;
            updateRecentFilesList();
            recentFilesContainer.style.display = 'block';
        }
    } catch (error) {
        console.error('Error loading recent files:', error);
    }
}

// Function to update the recent files list in the UI
function updateRecentFilesList() {
    recentFilesList.innerHTML = '';
    
    recentFiles.forEach((file, index) => {
        const fileItem = document.createElement('div');
        fileItem.className = 'recent-file-item';
        
        const fileName = document.createElement('div');
        fileName.className = 'recent-file-name';
        fileName.textContent = file.name;
        fileItem.appendChild(fileName);
        
        const removeBtn = document.createElement('span');
        removeBtn.className = 'recent-file-remove';
        removeBtn.textContent = '×';
        removeBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            removeRecentFile(index);
        });
        fileItem.appendChild(removeBtn);
        
        fileItem.addEventListener('click', () => {
            loadRecentFile(file.path);
        });
        
        recentFilesList.appendChild(fileItem);
    });
    
    if (recentFiles.length > 0) {
        recentFilesContainer.style.display = 'block';
    } else {
        recentFilesContainer.style.display = 'none';
    }
}

// Function to add a file to recent files
async function addRecentFile(filePath, fileName) {
    // Check if file already exists in recent files
    const existingIndex = recentFiles.findIndex(file => file.path === filePath);
    if (existingIndex !== -1) {
        // Move to top if exists
        recentFiles.splice(existingIndex, 1);
    }
    
    // Add to beginning of array (most recent)
    recentFiles.unshift({
        path: filePath,
        name: fileName,
        timestamp: Date.now()
    });
    
    // Limit to 5 recent files
    if (recentFiles.length > 5) {
        recentFiles.pop();
    }
    
    // Save to localStorage
    await window.api.saveRecentFiles(recentFiles);
    
    // Update UI
    updateRecentFilesList();
}

// Function to remove a file from recent files
async function removeRecentFile(index) {
    recentFiles.splice(index, 1);
    await window.api.saveRecentFiles(recentFiles);
    updateRecentFilesList();
}

// Function to load a recent file
async function loadRecentFile(filePath) {
    try {
        // Show loading indicator
        setLoading(true);
        
        // Show progress bar
        uploadProgressContainer.style.display = 'block';
        uploadProgressBar.style.width = '50%';
        
        // Parse the PDF
        const pdfData = await window.api.parsePdf(filePath);
        
        // Complete progress
        uploadProgressBar.style.width = '100%';
        setTimeout(() => {
            uploadProgressContainer.style.display = 'none';
            uploadProgressBar.style.width = '0%';
        }, 1000);
        
        if (pdfData.error) {
            showError(`Error parsing PDF: ${pdfData.error}`);
            return;
        }
        
        // Store document content for querying
        documentContent = pdfData.text;
        currentPdfPath = filePath;
        
        // Display PDF content (first 2000 chars with ellipsis if longer)
        const displayText = pdfData.text.length > 2000 
            ? pdfData.text.substring(0, 2000) + '...' 
            : pdfData.text;
        pdfContent.textContent = displayText;
        
        // Enable chat functionality
        queryInput.disabled = false;
        sendQueryBtn.disabled = false;
        
        // Add system message
        addMessage(`PDF loaded: ${pdfData.info.title}. You can now ask questions about the content.`, 'bot');
        
    } catch (error) {
        // Hide progress on error
        uploadProgressContainer.style.display = 'none';
        uploadProgressBar.style.width = '0%';
        showError(`Error: ${error.message}`);
    } finally {
        setLoading(false);
    }
}

// Function to select a PDF file
async function selectPdf() {
    try {
        // Show loading indicator
        setLoading(true);
        
        // Call the main process to open file dialog
        const filePath = await window.api.selectPdf();
        
        if (filePath) {
            currentPdfPath = filePath;
            
            // Show progress bar
            uploadProgressContainer.style.display = 'block';
            simulateProgress();
            
            // Parse the PDF
            const pdfData = await window.api.parsePdf(filePath);
            
            // Complete progress
            uploadProgressBar.style.width = '100%';
            setTimeout(() => {
                uploadProgressContainer.style.display = 'none';
                uploadProgressBar.style.width = '0%';
            }, 1000);
            
            if (pdfData.error) {
                showError(`Error parsing PDF: ${pdfData.error}`);
                return;
            }
            
            // Store document content for querying
            documentContent = pdfData.text;
            
            // Add to recent files
            const fileName = pdfData.info.title || filePath.split('/').pop();
            addRecentFile(filePath, fileName);
            
            // Display PDF content (first 2000 chars with ellipsis if longer)
            const displayText = pdfData.text.length > 2000 
                ? pdfData.text.substring(0, 2000) + '...' 
                : pdfData.text;
            pdfContent.textContent = displayText;
            
            // Enable chat functionality
            queryInput.disabled = false;
            sendQueryBtn.disabled = false;
            
            // Add system message
            addMessage('PDF loaded successfully! You can now ask questions about the content.', 'bot');
        } else {
            // Hide progress if canceled
            uploadProgressContainer.style.display = 'none';
            uploadProgressBar.style.width = '0%';
        }
    } catch (error) {
        // Hide progress on error
        uploadProgressContainer.style.display = 'none';
        uploadProgressBar.style.width = '0%';
        showError(`Error: ${error.message}`);
    } finally {
        setLoading(false);
    }
}

// Simulate progress for better UX
function simulateProgress() {
    let progress = 0;
    const interval = setInterval(() => {
        progress += 5;
        if (progress > 60) {
            clearInterval(interval);
            return;
        }
        uploadProgressBar.style.width = `${progress}%`;
    }, 100);
}

// Function to send a query about the document
async function sendQuery() {
    const query = queryInput.value.trim();
    
    if (!query || !documentContent) return;
    
    try {
        // Add user message to chat
        addMessage(query, 'user');
        
        // Clear input
        queryInput.value = '';
        
        // Show loading indicator
        setLoading(true);
        
        // Call the main process to query the document
        const response = await window.api.queryDocument(query, documentContent);
        
        // Add response to chat
        addMessage(response, 'bot');
    } catch (error) {
        showError(`Error: ${error.message}`);
    } finally {
        setLoading(false);
    }
}

// Helper function to add a message to the chat
function addMessage(text, sender) {
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('message');
    messageDiv.classList.add(sender === 'user' ? 'user-message' : 'bot-message');
    messageDiv.textContent = text;
    
    chatMessages.appendChild(messageDiv);
    
    // Scroll to bottom
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Helper function to show error messages
function showError(message) {
    addMessage(message, 'bot');
    console.error(message);
}

// Helper function to toggle loading indicator
function setLoading(isLoading) {
    loadingIndicator.style.display = isLoading ? 'block' : 'none';
    sendQueryBtn.disabled = isLoading;
    selectPdfBtn.disabled = isLoading;
}
