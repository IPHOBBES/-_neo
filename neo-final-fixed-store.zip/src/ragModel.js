// Enhanced RAG model implementation with more conversational responses
const { RecursiveCharacterTextSplitter } = require("langchain/text_splitter");

// In-memory vector store for document chunks
let vectorStore = null;

// Store for previously asked questions and their contexts
let conversationHistory = [];

// Simple embedding function that creates vector representations of text
function createEmbedding(text) {
  // Convert text to lowercase and remove extra whitespace
  const normalizedText = text.toLowerCase().trim().replace(/\s+/g, ' ');
  
  // Create a simple hash-based embedding (not for production use)
  const hashCode = str => {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32bit integer
    }
    return hash;
  };
  
  // Create a 128-dimensional vector based on character n-grams
  const vector = new Array(128).fill(0);
  const words = normalizedText.split(' ');
  
  words.forEach((word, i) => {
    const h = Math.abs(hashCode(word)) % 128;
    vector[h] += 1;
    
    // Add bigram features if possible
    if (i < words.length - 1) {
      const bigram = `${word} ${words[i+1]}`;
      const h2 = Math.abs(hashCode(bigram)) % 128;
      vector[h2] += 0.5;
    }
  });
  
  // Normalize the vector
  const magnitude = Math.sqrt(vector.reduce((sum, val) => sum + val * val, 0));
  return vector.map(val => magnitude > 0 ? val / magnitude : 0);
}

// Enhanced similarity calculation between two vectors
function cosineSimilarity(vecA, vecB) {
  if (vecA.length !== vecB.length) {
    throw new Error("Vectors must be of the same length");
  }
  
  let dotProduct = 0;
  let normA = 0;
  let normB = 0;
  
  for (let i = 0; i < vecA.length; i++) {
    dotProduct += vecA[i] * vecB[i];
    normA += vecA[i] * vecA[i];
    normB += vecB[i] * vecB[i];
  }
  
  normA = Math.sqrt(normA);
  normB = Math.sqrt(normB);
  
  if (normA === 0 || normB === 0) {
    return 0;
  }
  
  return dotProduct / (normA * normB);
}

// Initialize the vector store with document chunks
async function initializeVectorStore(chunks) {
  try {
    console.log(`Initializing vector store with ${chunks ? chunks.length : 0} chunks`);
    
    // Reset conversation history when loading a new document
    conversationHistory = [];
    
    // Handle empty or undefined chunks
    if (!chunks || chunks.length === 0) {
      console.log("Warning: No chunks provided to initialize vector store");
      // Create a dummy document to prevent errors
      vectorStore = [{
        pageContent: "No content available. Please load a document with extractable text.",
        metadata: { source: "system", chunk: 0 },
        embedding: new Array(128).fill(0)
      }];
      return { success: true, chunkCount: 0, warning: "No chunks available" };
    }
    
    // Create documents with embeddings
    const documents = chunks.map((chunk, i) => {
      const embedding = createEmbedding(chunk);
      return {
        pageContent: chunk,
        metadata: { source: "document", chunk: i },
        embedding: embedding
      };
    });
    
    // Store documents in memory
    vectorStore = documents;
    console.log(`Vector store initialized with ${documents.length} documents`);
    
    return { success: true, chunkCount: chunks.length };
  } catch (error) {
    console.error("Error initializing vector store:", error);
    // Create a fallback vector store with an error message
    vectorStore = [{
      pageContent: `Error initializing vector store: ${error.message}. Please try loading a different document.`,
      metadata: { source: "error", chunk: 0 },
      embedding: new Array(128).fill(0)
    }];
    return { success: false, error: error.message };
  }
}

// Enhanced similarity search
async function similaritySearch(query, count = 5) {
  if (!vectorStore || vectorStore.length === 0) {
    console.log("Warning: Vector store not initialized or empty");
    throw new Error("Vector store not initialized. Please load a document first.");
  }
  
  try {
    console.log(`Performing similarity search for query: "${query}"`);
    
    // Create query embedding
    const queryEmbedding = createEmbedding(query);
    
    // Calculate similarity scores
    const scoredDocuments = vectorStore.map(doc => {
      const score = cosineSimilarity(queryEmbedding, doc.embedding);
      return { ...doc, score };
    });
    
    // Sort by similarity score (descending)
    scoredDocuments.sort((a, b) => b.score - a.score);
    
    // Return top results
    const results = scoredDocuments.slice(0, count);
    console.log(`Found ${results.length} relevant chunks`);
    
    return results;
  } catch (error) {
    console.error("Error performing similarity search:", error);
    throw error;
  }
}

// Generate a more conversational response
async function generateResponse(query, documentContent) {
  try {
    console.log(`Generating response for query: "${query}"`);
    console.log(`Document content length: ${documentContent ? documentContent.length : 0}`);
    
    // Handle empty document content
    if (!documentContent || documentContent.trim().length === 0) {
      return "I don't have any document content to work with. Please load a document so I can help answer your questions.";
    }
    
    if (!vectorStore || vectorStore.length === 0) {
      // If vector store isn't initialized, initialize it with the document content
      console.log("Vector store not initialized, creating chunks from document content");
      const splitter = new RecursiveCharacterTextSplitter({
        chunkSize: 1000,
        chunkOverlap: 200,
      });
      
      try {
        const chunks = await splitter.splitText(documentContent);
        console.log(`Created ${chunks.length} chunks from document content`);
        
        // Ensure we have at least one chunk
        if (chunks.length === 0) {
          console.log("No chunks created, using entire document as one chunk");
          chunks.push(documentContent);
        }
        
        await initializeVectorStore(chunks);
      } catch (error) {
        console.error("Error creating chunks:", error);
        // Use the entire document as one chunk
        await initializeVectorStore([documentContent]);
      }
    }
    
    // Find relevant chunks from the document
    const relevantChunks = await similaritySearch(query);
    
    if (relevantChunks.length === 0) {
      return "I couldn't find information about that in the document. Could you try rephrasing your question?";
    }
    
    // Extract the content from the relevant chunks
    const contextTexts = relevantChunks.map(chunk => chunk.pageContent);
    
    // Combine the context into a single string
    const context = contextTexts.join('\n\n');
    
    // Add to conversation history
    conversationHistory.push({
      query,
      context,
      timestamp: Date.now()
    });
    
    // Create a more conversational response using the context
    const response = generateConversationalAnswer(query, context);
    console.log("Generated response successfully");
    
    return response;
  } catch (error) {
    console.error("Error generating response:", error);
    return `I ran into a problem while processing your question. Let's try a different approach or question.`;
  }
}

// Generate a more conversational answer without formulaic phrases
function generateConversationalAnswer(query, context) {
  console.log("Generating conversational answer");
  
  // Handle empty context
  if (!context || context.trim().length === 0) {
    return "I couldn't find relevant information in the document to answer your question.";
  }
  
  // Lowercase for easier matching
  const queryLower = query.toLowerCase();
  const contextLower = context.toLowerCase();
  
  // Extract sentences that might contain the answer
  const sentences = context.split(/[.!?]+/).filter(s => s.trim().length > 0);
  console.log(`Extracted ${sentences.length} sentences from context`);
  
  // Score sentences based on keyword matching with the query
  const queryWords = queryLower.split(/\W+/).filter(w => w.length > 2);
  
  const scoredSentences = sentences.map(sentence => {
    const sentenceLower = sentence.toLowerCase();
    let score = 0;
    
    // Score based on query word matches
    queryWords.forEach(word => {
      if (sentenceLower.includes(word)) {
        score += 1;
      }
    });
    
    // Bonus for sentences that contain multiple query words close together
    let wordCount = 0;
    queryWords.forEach(word => {
      if (sentenceLower.includes(word)) {
        wordCount++;
      }
    });
    
    if (wordCount > 1) {
      score += wordCount;
    }
    
    return { sentence: sentence.trim(), score };
  });
  
  // Sort by score (descending)
  scoredSentences.sort((a, b) => b.score - a.score);
  
  // Get top sentences
  const topSentences = scoredSentences.slice(0, 3).filter(s => s.score > 0);
  console.log(`Found ${topSentences.length} relevant sentences`);
  
  if (topSentences.length === 0) {
    // If no relevant sentences found, return a generic response with the first few sentences
    return "I don't see specific information about that in the document, but here's some general content that might be relevant: " + 
           sentences.slice(0, 2).map(s => s.trim()).join(". ");
  }
  
  // Check conversation history for variety in responses
  const isRepeatQuestion = conversationHistory.length > 1 && 
                          conversationHistory.slice(0, -1).some(h => 
                            h.query.toLowerCase().includes(queryLower) || 
                            queryLower.includes(h.query.toLowerCase()));
  
  // Construct a conversational answer based on question type and history
  let answer = "";
  
  // Vary the opening phrases to avoid repetition
  const openingPhrases = [
    "",
    "I found that ",
    "The document mentions that ",
    "According to the information, ",
    "It looks like ",
    "From what I can see, "
  ];
  
  // Select an opening phrase, with more variety for repeat questions
  const openingIndex = isRepeatQuestion ? 
                      Math.floor(Math.random() * openingPhrases.length) : 
                      Math.floor(Math.random() * 3);
  
  answer = openingPhrases[openingIndex];
  
  // Check question type to format appropriate response
  if (queryLower.startsWith("what is") || queryLower.startsWith("what are")) {
    answer += topSentences[0].sentence;
    if (topSentences.length > 1) {
      answer += ". " + topSentences[1].sentence;
    }
  } else if (queryLower.startsWith("how to") || queryLower.startsWith("how do")) {
    if (answer === "") answer = "You can ";
    answer += topSentences[0].sentence.toLowerCase().replace(/^you can |^to |^you should |^should /, "");
    if (topSentences.length > 1) {
      answer += ". " + topSentences[1].sentence;
    }
  } else if (queryLower.startsWith("why")) {
    if (answer === "") answer = "Because ";
    answer += topSentences[0].sentence.toLowerCase().replace(/^because |^since |^as /, "");
    if (topSentences.length > 1) {
      answer += ". " + topSentences[1].sentence;
    }
  } else {
    // For other question types
    if (answer === "") {
      // If we didn't use an opening phrase, just use the sentences directly
      answer = topSentences.map(s => s.sentence).join(". ");
    } else {
      // Otherwise, append the sentences to the opening phrase
      answer += topSentences.map(s => s.sentence).join(". ");
    }
  }
  
  // Add variety to conclusions based on conversation history
  if (conversationHistory.length > 2 && !isRepeatQuestion) {
    // For users who have had several interactions, occasionally add a follow-up question
    const followUps = [
      " Does that help with what you wanted to know?",
      " Is there anything specific about this you'd like me to elaborate on?",
      " Would you like more details on any part of this?"
    ];
    
    if (Math.random() > 0.7) {
      answer += followUps[Math.floor(Math.random() * followUps.length)];
    }
  }
  
  return answer;
}

module.exports = {
  initializeVectorStore,
  similaritySearch,
  generateResponse
};
