const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const { extractTextFromPdf, splitTextIntoChunks, preprocessText } = require('./pdfProcessor');
const { initializeVectorStore, generateResponse } = require('./ragModel');

// Simple in-memory storage for recent files
let recentFiles = [];

// Handle creating/removing shortcuts on Windows when installing/uninstalling.
if (require('electron-squirrel-startup')) {
  app.quit();
}

let mainWindow;

const createWindow = () => {
  // Create the browser window.
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
    backgroundColor: '#000000',
    icon: path.join(__dirname, 'assets', 'icon.png')
  });

  // and load the index.html of the app.
  mainWindow.loadFile(path.join(__dirname, 'index.html'));

  // Open the DevTools in development mode
  if (process.env.NODE_ENV === 'development') {
    mainWindow.webContents.openDevTools();
  }
};

// This method will be called when Electron has finished
// initialization and is ready to create browser windows.
app.on('ready', createWindow);

// Quit when all windows are closed, except on macOS.
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  // On OS X it's common to re-create a window in the app when the
  // dock icon is clicked and there are no other windows open.
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});

// IPC handlers for communication with renderer process

// Handle PDF file selection
ipcMain.handle('select-pdf', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile'],
    filters: [
      { name: 'PDF Files', extensions: ['pdf'] },
      { name: 'All Files', extensions: ['*'] }
    ]
  });
  
  if (result.canceled || result.filePaths.length === 0) {
    return null;
  }
  
  return result.filePaths[0];
});

// Handle PDF parsing
ipcMain.handle('parse-pdf', async (event, filePath) => {
  try {
    // Extract text from PDF
    const pdfData = await extractTextFromPdf(filePath);
    
    // Preprocess the text
    pdfData.text = preprocessText(pdfData.text);
    
    return pdfData;
  } catch (error) {
    console.error('Error parsing PDF:', error);
    return { error: error.message };
  }
});

// Handle document querying
ipcMain.handle('query-document', async (event, query, documentContent) => {
  try {
    // Split text into chunks
    const chunks = await splitTextIntoChunks(documentContent);
    
    // Initialize vector store with chunks
    await initializeVectorStore(chunks);
    
    // Generate response
    const response = await generateResponse(query, documentContent);
    
    return response;
  } catch (error) {
    console.error('Error querying document:', error);
    return `Error: ${error.message}`;
  }
});

// Handle saving recent files
ipcMain.handle('save-recent-files', async (event, files) => {
  try {
    recentFiles = files;
    return true;
  } catch (error) {
    console.error('Error saving recent files:', error);
    return false;
  }
});

// Handle getting recent files
ipcMain.handle('get-recent-files', async () => {
  try {
    // Verify files still exist
    const validFiles = [];
    for (const file of recentFiles) {
      try {
        if (fs.existsSync(file.path)) {
          validFiles.push(file);
        }
      } catch (err) {
        console.log(`File no longer exists: ${file.path}`);
      }
    }
    
    // Update if some files were removed
    if (validFiles.length !== recentFiles.length) {
      recentFiles = validFiles;
    }
    
    return validFiles;
  } catch (error) {
    console.error('Error getting recent files:', error);
    return [];
  }
});
