#!/bin/bash

# Script to run the RAG Electron application
cd /home/ubuntu/rag-electron-app
npm start
